> Historical study record from 2026-09-15, retained for provenance. Public packaging does not reset development or test exposure. Paths below refer to the original study archive.

# Signal extension development scope

Recorded before new signal diagnostics, 2026-09-15. Original frozen illustrated paper and all results are preserved.

Development data: previously used PANDA and MELFA training/validation records only for construction and tuning. Existing previously exposed test records may later be evaluated as retrospective transfer, never as new holdout. SARCOS remains supporting legacy evidence, not a temporal-signal dataset.

Stage 1 diagnostic: continuous-record input-only descriptors (local velocity energy, acceleration energy, and their ratio; Fourier features only if real timestamps and sample-rate audit support them). Windows must never cross recording boundaries. Fit all descriptor normalization/bin thresholds from training only. Associate these conditions with residuals of fixed archived centered/full KRR, using validation records; preserve all bins and both robots. No label-derived descriptor at inference. No new holdout payload read before method freeze.

Hypothesis: global feature matching leaves condition-specific errors that can be reduced by a condition-aware, task-weighted subset target. Reject mechanistic explanation if diagnostic error does not vary across conditions or if condition information offers no improvement over a matched no-condition ablation. Noise sensitivity and record composition are alternatives.

Development cap: at most two rule families and 12 hyperparameter configurations per family, fixed method selection using existing validation group NMSE. Baselines share the predictor family, state inputs, candidate pools, dictionary budgets and documented calibration. No test-based retuning. Primary new holdout endpoint: equal-record mean normalized MSE; report each recording and physical RMSE. Small sample size interpreted at observed-record level; no frame-wise significance. Budgets 64,128,256; primary 256. No seeds dropped; stochastic baseline uses ten prespecified seeds 7310..7319. New source unavailable does not license fabricated data.

Task-authorized public data/CPU work only. No purchases, upload, contact, or submission. New revision will report actual outcomes directly without repetitive self-disclaimers.
