> Historical study record from 2026-09-15, retained for provenance. Public packaging does not reset development or test exposure. Paths below refer to the original study archive.

# Signal-conditioned loss dictionary selection: frozen evaluation protocol

Version 1, 2026-09-15, prepared after development and before new holdout payload access. This is a local protocol record. Development history and all 24 (12 per robot) rule comparisons are retained.

## Question and algorithm

Keep the state-only SE KRR predictor fixed. Does learning the allocation of a finite dictionary from record-cross-fitted errors and local derivative-energy conditions improve prediction compared with global centered/full-loss matching and task/representation ablations?

Signal features use a centered 31-original-row average, separately within consecutive source dataframe index segments: log(1+mean joint normalized acceleration energy), log((acceleration energy+1e-6)/(velocity energy+1e-6)). Training-only mean squared velocity/acceleration scale each joint. This is offline selection using existing logs, not a causal online representation. MELFA has no timestamps; features have no claimed Hz interpretation. The predictor at test time still receives q,dq,ddq only.

From historical training records, leave one record out, fit a 256-point random pilot KRR with seed7300+record_index and fold-training-only scaling, predict the omitted record. A common previously fixed predictor hyperparameter pair is used. Normalize physical squared residuals by the main training output variances and average joints. These pilot errors estimate conditional difficulty; they are not independent test results.

Under the development cap recorded in research/development_scope.md before the first signal diagnostic, two families were specified and evaluated during development: quota-based within-condition matching and global matching to a learned target. Each used acceleration quartiles or a 2x2 acceleration/derivative-ratio partition, and exponents {0.5,1,2}; 12 choices per robot, chosen by equal-record validation NMSE at m256. Both selected global weighted matching. Final choices in config/final_method_choices.json: PANDA energy exponent0.5; MELFA joint exponent1.

For bin b with count n_b and pilot residual sum R_b, e_b=(R_b+32*pooled_error)/(n_b+32). Clip e_b/pooled_error to [0.25,4], raise to the chosen exponent; target bin mass proportional to n_b times this quantity. Give each candidate its bin mass divided by n_b. Greedy centered-loss kernel mean matching uses this weighted empirical target; the fitted KRR is unweighted. Equal target weights recover original centered-loss matching. This is a condition-informed target and an explicit algorithmic specialization; no new generic conditional-compression theorem is implied.

## Data and history

Historical PANDA/MELFA train and validation arrays are byte-identical to the previous manuscript. Those observations determine scaling, descriptors, pilot residuals, hyperparameters and rule selection. Original test records have already been exposed and are retrospective transfer evaluation.

New holdout: all four MELFA archive records frozen in data_audit/holdout_membership_freeze.json, which previous converters skipped before payload reading. One range0.5 seed6 record; range1.4 seeds0,5,10. All are from the same available source archive. Three share excitation seed labels with another previously used amplitude condition; do not count them as independent new acquisitions. Keep every quality-valid record. Quality-v2 rules are based on development schema and frozen before opening payloads. No quality exclusion uses prediction error. Report short record and amplitude groups explicitly.

## Main comparison

Primary m256, SE with shared previously fixed KRR parameters. Auxiliary m64/128. Methods: random, k-center, GP variance, GEMSS-MO, centered, full, signal_task; ablations residual_only, random_bins, signal_static, weighted_random. The learned rule is deterministic. Ten stochastic evaluation seeds7310..7319, three separate validation seeds7320..7322. Random bins preserve exact condition counts using permutation seed7341; learn their weights through the same residual pipeline. residual_only clips per-point rather than bin-averaged error. signal_static weights ordinal condition labels by 1,2,3,4 (a fixed-label weighting control, not a monotonic physical-frequency claim). weighted_random uses learned probabilities without replacement and removes kernel matching.

All selectors access the same labeled candidate logs and state-only predictor; side computation and training-record pilot cost for the new rule are reported. The proposed rule alone received 12 criterion configurations; this search cost is reported and total criterion-tuning effort is not claimed equal across selectors. Each method receives the same secondary 3x3 predictor grid (scale times {0.5,1,2}; regularizer times {0.1,1,10}) at256 with its frozen dictionaries. Selection hyperparameters remain the primary common pair. Primary comparison cannot be replaced by the secondary result after seeing holdout.

A full SKT author-implementation comparison is an additional fixed protocol task. If power-of-two restrictions require a smaller pool, use a seed7350 uniform1024 candidate subset shared by every compared method, output64/128/256 when supported; no repeated-point padding. Recompute cross-record pilots entirely within that candidate pool (64 points per pilot) so all labels used come from the same pool. Fixed shared predictor pair; no new criterion tuning. Use previously frozen bin definitions/exponents. Report this separately from the full candidate pool. Comparison methods random/centered/full/signal_task/SKT. No parameters chosen using holdout. Implement and freeze this baseline protocol before any of its test predictions; new holdout may be read only when primary methods are frozen and this extra-comparison choice remains irrevocable.

## Endpoints and statistics

Primary: equal-record mean NMSE on the four quality-valid new records; per-record average squared error normalized by historical training joint variance. Random reference averages all ten seeds within each record before the paired difference. Secondary: record-equal mean physical torque RMSE in N m, budgets, and secondary retuned predictors. Report all individual record values; shared seeds and n<=4 make frame-wise significance and population claims inappropriate. Any paired bootstrap is descriptive only and must identify the four records as resampling units. No record removed for influence. Historical Panda/MELFA tests are separate retrospective results, not combined with the new holdout.

Mechanism checks: development and retrospective errors by all signal bins; selected-bin mass and learned target; no-signal residual ablation, fixed-label weights and random-bin negative control; unweighted-centered reduction. New rule fails its principal comparative hypothesis if it does not lower the primary holdout NMSE relative to random. Component-specific benefit requires the corresponding ablation comparison, rather than overall improvement alone.

## Execution and stopping

All configurations, indices, normalization, seeds, per-record predictions, costs, versions and hashes retained. Numerical failures are logged and reruns linked. No further rule search or test-based changes after freeze. Four-record holdout could reject the method; then retain actual results and present the conditional scientific conclusion. Final prose states observed findings directly, keeping data identities and scope precise. Original 4+1 ICASSP template remains unchanged; references remain17–23.

## SKT implementation identity fixed before reveal

The author NPR Compress++ wrapper outputs sqrt(N), so the aligned experiment uses the author complete direct KT-SPLIT plus KT-SWAP path on 1024 candidates at64/128/256, unique=True, delta0.5. This is named SKT (direct KT), not the default NPR Compress++ pipeline. The author kernel is k^2+k dot(y,yprime); pass selection labels scaled by sqrt(2/J) and lengthscale s sqrt(d) to match our multi-output centered-loss Gram matrix. Predictor labels and KRR are unchanged. This configuration does not transfer the original scalar statistical guarantees. Author version and parity are recorded in skt_baseline/provenance.json and parity.json.
