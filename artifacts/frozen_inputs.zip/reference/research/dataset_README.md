<!--
Created by Mitsubishi Electric Research Laboratories (MERL), 2024

SPDX-License-Identifier: CC-BY-SA-4.0
-->

# Robot Inverse Dynamics Dataset

## Introduction
The Robot Inverse Dynamics Dataset is a collection of trajectories and joint torque measurements of two robotic manipulators, a 7 DoF Franka Emika Panda, and a 6 DOF MELFA RV4FL. Additionally, the dataset contains the inverse dynamical models and other useful quantities learned to reproduce the results reported on our reference paper "A Black-Box Physics-Informed Estimator based on Gaussian Process Regression for Robot Inverse Dynamics Identification". The proposed model relies on a novel multidimensional kernel, called Lagrangian Inspired Polynomial (LIP) kernel. The code to reproduce the results with the LIP model can be found [here](https://github.com/merlresearch/LIP4RobotInverseDynamics).

## Dataset Organization

- The size of the unzipped dataset is ~700MB.
- The directory `Simulated_PANDA` contains the trajectories, models and results obtained on different configurations of a Franka Emika PANDA robot, simulated using sympybotics.
- The directory `Robots` contains the data, models and results obtained on two real robots, a Franka Emika PANDA and a Mitsubishi Electric MELFA RV4FRL
- The experiments collected consist of sinusoidal and sum of sinusoidal trajectories designed in joint space.
- The Lagrangian Inspired Polynomial model proposed in "A Black-Box Physics-Informed Estimator based on Gaussian Process Regression for Robot Inverse Dynamics Identification" and all the baseline models already trained are saved in this dataset.

More details on each dataset follow.
### Simulated PANDA
The experimental results are located in the `Simulated_PANDA/Results` directory. This directory is divided into five subfolders, each representing a different configuration of the Panda robot. The configurations vary by the number of moving joints, ranging from 3 to 7. For example, the `Simulated_PANDA/Results/3dof` folder contains the results of simulations with only the first 3 joints of the simulated PANDA in motion.
Each of the five subfolders contains the results from 50 different seeds. For each seed, 2 trajectories have been generated: one for training the models and one for testing. 5 type of models are trained on the training trajectory and evaluated on the test trajectories:
- `LK_GIP_sum`: is the Lagrangian Inspired Polynomial model proposed in the paper.
- `LK_RBF_1_sc`: is a multi-output GP model that assumes an RBF kernel as prior for the Lagrangian of the system.
- `m_ind_RBF`: is a series of independent GP models, with RBF kernel as prior, trained each to estimate the torque of a single joint
- `m_ind_GIP`:  is a series of independent GP models, with the [GIP kernel](https://ieeexplore.ieee.org/abstract/document/8854821) as prior, trained each to estimate the torque of a single joint.
- `Delan`: is model proposed in [Deep Lagrangian Neural Network](https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=8968268).

The learned models parameters are saved as either `.torch` or `.pt` files in:
-  `tr_num_sin50_train-test_num_sin50_seed[i]_model_[GP_model_name].pt`
-  `tr_num_sin50_train-test_num_sin50_seed[i]_model_Delan.torch`

where *i* goes from 1 to 50 and *GP_model_name* is contained in {`LK_GIP_sum`, `LK_RBF_1_sc`, `m_ind_RBF`, `m_ind_GIP`}.

The estimates along the test trajectories are saved as pickle files in:
- `tr_num_sin50_train-test_num_sin50_seed[i]_model_[model_name]_test1_estimates.pkl`

where *i* goes from 1 to 50 and *model_name* is contained in {`LK_GIP_sum`, `LK_RBF_1_sc`, `m_ind_RBF`, `m_ind_GIP`, `Delan`}.

Each `.pkl` file contains a list.
For the   `LK_GIP_sum`, `LK_RBF_1_sc` and `Delan` models, the list includes the following three items:
- a dictionary with key : value pairs as follows:
    - `Y` : [ndof x Nsamples] numpy array with true torque values corrupted by noise
    - `Y_hat` : [ndof x Nsamples] numpy array with estimated torque values
    - `Y_noiseless` : [ndof x Nsamples] numpy array with true torque values
    - [Except for Delan]  `Y_var` : [ndof x Nsamples] numpy array with the posterior variance of the estimates
    - `m` : [ndof x Nsamples] numpy array with true inertial torque
    - `m_hat` : [ndof x Nsamples] numpy array with estimated inertial torque
    - `c` : [ndof x Nsamples] numpy array with true coriolis torque
    - `c_hat` : [ndof x Nsamples] numpy array with estimated inertial torque
    - `g` : [ndof x Nsamples] numpy array with true gravitational torque
    - `g_hat` : [ndof x Nsamples] numpy array with estimated gravitational torque
    - `T` : [ndof x Nsamples] numpy array with true Kinetic energy
    - `T_hat` : [ndof x Nsamples] numpy array with estimated Kinetic energy
    - `U` : [ndof x Nsamples] numpy array with true Potential energy
    - `U_hat` : [ndof x Nsamples] numpy array with estimated Potential energy
    - `L` : [ndof x Nsamples] numpy array with true Lagrangian
    - `L_hat` : [ndof x Nsamples] numpy array with estimated Lagrangian
- a [ndof x ndof x Nsamples] numpy array with true inertia matrices
- a [ndof x ndof x Nsamples] numpy array with estimated inertia matrices

For the  `m_ind_GIP`, and `m_ind_RBF` models, the list contains two dictionaries, one with the estimates on the training trajectories, one with the test trajectories, respectively. Both the disctionaries have key : value pairs as follows:
- `Y` : [ndof x Nsamples] numpy array with true torque values corrupted by noise
- `Y_hat` : [ndof x Nsamples] numpy array with estimated torque values
- `Y_noiseless` : [ndof x Nsamples] numpy array with true torque values
- `Y_var` : [ndof x Nsamples] numpy array with the posterior variance of the estimates

### Robots
The `Robots/` directory includes the experiments run in two real robot manipulators a `MELFA RV4FRL` and a `Franka Emika Panda`.
#### MELFA_RV4FRL
The `Robots/MELFA_RV4FRL/Experiments` directory contains the trajectories collected on the robot, while the `Robots/MELFA_RV4FRL/Results` directory contains the learned models and the estimates along the collected trajectories.

6 type of models are trained on the training trajectory and evaluated on the test trajectories:
- `LK_GIP_sum`: is the Lagrangian Inspired Polynomial model proposed in the paper.
- `LK_RBF_1_sc`: is a multi-output GP model that assumes an RBF kernel as prior for the Lagrangian of the system.
- `m_ind_RBF`: is a series of independent GP models with RBF kernel as prior, trained each to estimate the torque of a single joint.
- `m_ind_GIP_with_friction`:  is a series of independent GP models with the [GIP kernel](https://ieeexplore.ieee.org/abstract/document/8854821) plus a parametric friction component as prior, trained each to estimate the torque of a single joint.
- `m_ind_SP`: is a series of independent GP models with parametric plus RBF kernel as prior, trained each to estimate the torque of a single joint.
- `parametricID`: parametric model derived with standard parametric identification with nominal robot parameters.

The organization of the `Robots/MELFA_RV4FRL/Experiments` and `Robots/MELFA_RV4FRL/Results` directories is detailed in the following.

- `Robots/MELFA_RV4FRL/Experiments` contains 18 `.pkl` files with joint positions, velocities, accelerations and torques. These files are divided into 2 groups:
    - `SumOfSin__w_f0.02__num_sin100__pos_range_0.5__50seconds__seed[i].pkl`
    - `SumOfSin__w_f0.02__num_sin100__pos_range_1.4__50seconds__seed[j].pkl`

    with i in {0, 1, 2, 3, 4, 7, 8, 9, 10} and j in {1, 2, 3, 4, 6, 7, 8, 9, 11}. The first group of trajectories is used for training the models, while the second group is used for testing. The joint positions in these trajectories are generated as sums of sinusoids. The two groups differ in the amplitude of the position range of the trajectories. Each .pkl file contains a pandas dataset with the following columns:
    - `q_i` with i=1,...,6 : measured joint torques
    - `dq_i` with i=1,...,6 : measured joint velocities
    - `ddq_i` with i=1,...,6 : measured joint accelerations
    - `tau_i` with i=1,...,6 : measured joint torques
    - `q_filt_i` with i=1,...,6 : filtered joint torques
    - `dq_filt_i` with i=1,...,6 : filtered joint velocities
    - `ddq_filt_i` with i=1,...,6 : filtered joint accelerations
    - `tau_filt_i` with i=1,...,6 : filtered joint torques

- `Robots/MELFA_RV4FRL/Results` directory includes the outcomes of all the evaluated models, trained on all the training trajectories and evaluated on all the test trajectories. The organization of the results is detailed in the following.

    - Single joint models (`m_ind_RBF`, `m_ind_GIP_with_frinction` and `m_ind_SP`): model parameters are saved in `100SmallRange-100LargeRange_seed[i]_low_vel_filt_model_[model_name].pt` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10}. Estimates on test trajectories are stored in `100SmallRange-100LargeRange_seed[i]_low_vel_filt_model_[model_name]_SumOfSin__w_f0.02__num_sin100__pos_range_1.4__50seconds__seed[j]_estimates.pkl` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10} and j in {1, 2, 3, 4, 6, 7, 8, 9, 11}.

    - LIP models (`LK_GIP_sum`): model parameters are saved in `100SmallRange-100LargeRange_seed[i]_linear_friction_with_NP_low_vel_filt_model_LK_GIP_sum.pt` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10}. Estimates on test trajectories are stored in `100SmallRange-100LargeRange_seed[i]_linear_friction_with_NP_low_vel_filt_model_LK_GIP_sum_SumOfSin__w_f0.02__num_sin100__pos_range_1.4__50seconds__seed[j]_estimates.pkl` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10} and j in {1, 2, 3, 4, 6, 7, 8, 9, 11}.

    - LSE models (`LK_RBF_1_sc`): model parameters are saved in `100SmallRange-100LargeRange_seed[i]_linear_friction_low_vel_filt_model_LK_RBF_1_sc.pt` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10}. Estimates on test trajectories are stored in `100SmallRange-100LargeRange_seed[i]_linear_friction_low_vel_filt_model_LK_RBF_1_sc_SumOfSin__w_f0.02__num_sin100__pos_range_1.4__50seconds__seed[j]_estimates.pkl` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10} and j in {1, 2, 3, 4, 6, 7, 8, 9, 11}.

    - Parametric models: Estimates on test trajectories are stored in `100SmallRange-100LargeRange_seed[i]_SumOfSin__w_f0.02__num_sin100__pos_range_0.9__50seconds__seed[j]_low_vel_model_parametricID_MELFA_test1_estimates.pkl` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10} and j in {1, 2, 3, 4, 6, 7, 8, 9, 11}.

    Each `.pkl` file contains a dictionaries with key : values pairs as following:
    - `Y` : 7 x Nsamples numpy array with measured filtered torque values
    - `Y_hat` : 7 x Nsamples numpy array with estimated torque values
    - `Y_var` : 7 x Nsamples numpy array with the posterior variance of the estimates

#### PANDA
The `Robots/PANDA/Experiments` directory contains the trajectories collected on the robot, while the `Robots/PANDA/Results` directory contains the learned models and the estimates along the collected trajectories.

4 type of models are trained on the training trajectory and evaluated on the test trajectories:
- `LK_GIP_sum`: is the Lagrangian Inspired Polynomial model proposed in the paper.
- `LK_RBF_1_sc`: is a multi-output GP model that assumes an RBF kernel as prior for the Lagrangian of the system.
- `m_ind_RBF`: is a series of independent GP models with RBF kernel as prior, trained each to estimate the torque of a single joint.
- `m_ind_GIP_with_friction`:  is a series of independent GP models with the [GIP kernel](https://ieeexplore.ieee.org/abstract/document/8854821) plus a parametric friction component as prior, trained each to estimate the torque of a single joint.


The organization of the `Robots/PANDA/Experiments` and `Robots/PANDA/Results` directories is detailed in the following.

`Robots/PANDA/Experiments` contains the collected trajectories stored in the files:
- `panda7dof_num_sin_50_seed_[i]_as_unfiltered.pkl` : contains raw joint position, velocities and torques
- `panda7dof_num_sin_50_seed_[i]_as_filtered_fcut4.0.pkl`: contains filtered joint position, velocities and torques
- `panda7dof_num_sin_50_seed_[i]_as_dynamic_components.pkl`: contains inertia matrices, coriolis and gravity torques

    with `i` in {2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 16, 18, 21, 22, 23, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38}.

    Models are trained and tested on the filtered trajectories. In particular, seeds from 2 to 18 are used for training, seeds from 21 to 38 are used for testing.

    Each unfiltered `.pkl` file contains a pandas dataset with columns:
        - `q_i` with i=1,...,6 : measured joint torques
    - `dq_i` with i=1,...,6 : measured joint velocities
    - `ddq_i` with i=1,...,6 : measured joint accelerations
    - `tau_i` with i=1,...,6 : measured joint torques
    - `t` : time (as a float)

    Each filtered `.pkl` file contains a pandas dataset with columns:
    - `q_i` with i=1,...,6 : filtered joint torques
    - `dq_i` with i=1,...,6 : filtered joint velocities
    - `ddq_i` with i=1,...,6 : filtered joint accelerations
    - `tau_i` with i=1,...,6 : filtered joint torques
    - `t` : time (as a float)

    Each dynamic_components `.pkl` file contains a list with:
    - `M` : 7 x 7 x Nsamples numpy array with inertia matrices
    - `c` : Nsamples x 7 numpy array with coriolis torques
    - `g` : Nsamples x 7 numpy array with gravity torques

`Robots/PANDA/Results` contains all the considered models trained on 12 different combinations of training trajectories and evaluated on all the test trajectories.
For each combination, 2 consecutive training seeds are used to train the models. For example, combination 0 trains the models using seeds 2 and 3, combination 1 trains the models using seeds 3 and 4, and so on.

Results are organized as detailed in the following:

- Single joint models (`m_ind_RBF`, `m_ind_GIP_with_frinction` ): model parameters are saved in `50-100-sin_two-dataset__comb[i]_model_[model_name].pt` with i ranging from 0 to 11. Estimates on test trajectories are stored in `50-100-sin_two-dataset_comb[i]_model_m_ind_RBF_panda7dof_num_sin_100_seed_[j]_as_filtered_fcut4.0_estimates.pkl` with i ranging from 0 to 11 and j in {21, 22, 23, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38}.

- LIP models (`LK_GIP_sum`): model parameters are saved in `50-100-sin_two-dataset_comb[i]_with_NP_model_LK_GIP_sum.pt` with i ranging from 0 to 11. Estimates on test trajectories are stored in `50-100-sin_two-dataset_comb[i]_with_NP_model_LK_GIP_sum_panda7dof_num_sin_100_seed_[j]_as_filtered_fcut4.0_estimates.pkl` with i ranging from 0 to 11 and j in {21, 22, 23, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38}.

- LSE models (`LK_RBF_1_sc`): model parameters are saved in `50-100-sin_two-dataset_comb[i]_with_linear_friction_model_LK_RBF_1_sc.pt` with i ranging from 0 to 11. Estimates on test trajectories are stored in `50-100-sin_two-dataset_comb[i]_with_linear_friction_model_LK_RBF_1_sc_panda7dof_num_sin_100_seed_[j]_as_filtered_fcut4.0_estimates.pkl` with i in {0, 1, 2, 3, 4, 7, 8, 9, 10} and j in {1, 2, 3, 4, 6, 7, 8, 9, 11} and j in {21, 22, 23, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38}.

    Each `.pkl` file contains a dictionaries with key : values pairs as following:
    - `Y` : 7 x Nsamples numpy array with measured filtered torque values
    - `Y_hat` : 7 x Nsamples numpy array with estimated torque values
    - `Y_var` : 7 x Nsamples numpy array with the posterior variance of the estimates


## Citation

If you use the Robot Inverse Dynamics dataset in your research, please cite our contribution:

```BibTex
@InProceedings{
title={ A Black-Box Physics-Informed Estimator based on Gaussian Process Regression for Robot Inverse Dynamics Identification},
author={ Giacomuzzo, G., Dalla Libera, A., Romeres, D.,},
booktitle={ IEEE Transaction on Robotics },
year={2024}
}
```

## Contact

Giulio Giacomuzzo: giulio.giacomuzzo@gmail.com

Alberto Dalla Libera: alberto.dallalibera.1@gmail.com

Diego Romeres: romeres@merl.com

## License

The Robot Inverse Dynamics dataset is released under [CC-BY-SA-4.0](https://creativecommons.org/licenses/by-sa/4.0/) license.

All data:

```
Created by Mitsubishi Electric Research Laboratories (MERL), 2024

SPDX-License-Identifier: CC-BY-SA-4.0
```
